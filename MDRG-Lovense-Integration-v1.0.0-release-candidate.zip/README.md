# MDRG Lovense Integration — Release Candidate 1.0.0

Community-made mod for My Dystopian Robot Girlfriend (MDRG). Uses MelonLoader, Intiface Central, and an included local bridge to route supported in-game telemetry to compatible devices.

## Requirements
- A legally installed, compatible Windows version of MDRG
- A compatible MelonLoader installation for the game
- Intiface Central running locally with a supported device connected
- Microsoft .NET 10 runtime (x64) for the included framework-dependent bridge

## Installation
1. Close the game and the bridge. Back up your game installation and existing Mods/MDRGMelon.dll and Mods/IntifaceBridge folder if updating.
2. Install a compatible MelonLoader version for MDRG if needed.
3. Extract the contents of this archive into your MDRG game directory, preserving the Mods directory layout. The mod DLL belongs in <game>/Mods/MDRGMelon.dll.
4. Install the .NET 10 runtime if not installed. Start Intiface Central and connect your supported device.
5. Launch MDRG and open the in-game website `lovense.ic`. Use its Connect control and device selection to configure output.
6. Begin with low intensity, confirm stop/disconnect behavior, and increase only as comfortable.

## Troubleshooting
- If `lovense.ic` is missing, confirm MelonLoader is installed and the mod DLL is directly in Mods.
- If the bridge fails to launch, confirm .NET 10 runtime is installed and the four bridge files are together in Mods/IntifaceBridge.
- If Intiface does not connect, ensure its local server is running and the device is paired.
- If settings or output differ from expectations, disconnect devices and do not continue until verified.

## Release status
This is an **unverified release candidate** assembled from uploaded Windows binaries. It has not been tested on a clean PC or verified for correct independent per-device intensity and cap behavior. Do not publish as a stable release before testing.

## Distribution
Do not include game assets or the full game in redistribution. Confirm licensing and redistribution permissions for any bundled dependencies before public release. No license for the mod is asserted here; add your own license if you own the rights to the code.
