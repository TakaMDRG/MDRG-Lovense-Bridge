# Quick install

Extract the ZIP into the MDRG installation folder so you have:

```
<game folder>/
  Mods/
    MDRGMelon.dll
    IntifaceBridge/
      IntifaceConnectionTest.exe
      IntifaceConnectionTest.dll
      IntifaceConnectionTest.deps.json
      IntifaceConnectionTest.runtimeconfig.json
```

Prerequisites: compatible MelonLoader, Intiface Central, and **.NET 10 runtime (x64)**.

Run Intiface Central, connect the device, start MDRG, open `lovense.ic`, and connect there. Keep the local bridge and Intiface available during play. Begin at low intensity and test stop/disconnect first.

For updates, back up existing files before overwriting them.
